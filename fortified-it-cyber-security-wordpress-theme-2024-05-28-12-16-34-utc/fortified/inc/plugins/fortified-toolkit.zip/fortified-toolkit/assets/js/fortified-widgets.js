// Home 1 Testimonial
jQuery(document).ready(function() {
    var owl = jQuery('.testimonials-section .owl-carousel');
    owl.owlCarousel({
        margin: 30,
        nav: false,
        loop: true,
        dots: true,
        autoplay: false,
        autoplayTimeout: 4500,
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 2
            },
            992: {
                items: 2
            }
        }
    })
})
// Home 1 Case Studies
jQuery(document).ready(function () {
    var owl = jQuery('.case_studies_section .owl-carousel');
    owl.owlCarousel({
        margin: 30,
        nav: true,
        loop: true,
        pagination: true,
        dots: true,
        autoplay:false,
        autoplayTimeout: 4500,
        responsive: {
            0: {
                dotsEach: 1,
                items: 1
            },
            576: {
                dotsEach: 1,
                items: 2
            },
            992: {
                dotsEach: 1,
                items: 3
            }
        }
    })
})

// Home 2 Testimonial
jQuery(document).ready(function() {
    var owl = jQuery('.home2-testimonial-section .owl-carousel');
    owl.owlCarousel({
        margin: 0,
        nav: false,
        loop: true,
        dots: true,
        autoplay: false,
        autoplayTimeout: 4500,
        responsive: {
            0: {
                items: 1
            },
            576: {
                items: 1
            },
            992: {
                items: 1
            }
        }
    })
})

// Home 3 Testimonial
jQuery(document).ready(function() {
    var owl = jQuery('.home3-testimonial-section .owl-carousel');
    owl.owlCarousel({
        margin: 0,
        nav: false,
        loop: true,
        dots: true,
        autoplay: false,
        autoplayTimeout: 4500,
        responsive: {
            0: {
                items: 1
            },
            576: {
                items: 1
            },
            992: {
                items: 1
            }
        }
    })
})
jQuery(document).ready(function () {
    var owl = jQuery('.security_testimonial_section .owl-carousel');
    owl.owlCarousel({
        margin: 30,
        nav: false,
        loop: true,
        pagination: true,
        dots: true,
        autoplay:false,
        autoplayTimeout: 4500,
        responsive: {
            0: {
                items: 1
            },
            576: {
                items: 1
            },
            992: {
                items: 1
            }
        }
    })
})
jQuery(document).ready(function () {
    var owl = jQuery('.secure_service-section .owl-carousel');
    owl.owlCarousel({
        margin: 30,
        nav: false,
        loop: true,
        pagination: true,
        dots: true,
        autoplay:false,
        autoplayTimeout: 4500,
        responsive: {
            0: {
                items: 1,
                dotsEach:1
            },
            576: {
                items: 2,
                dotsEach:1
            },
            992: {
                items: 3,
                dotsEach:1
            }
        }
    })
})
jQuery(document).ready(function () {
    var owl = jQuery('.secure_testimonial_section .owl-carousel');
    owl.owlCarousel({
        margin: 30,
        nav: false,
        loop: true,
        pagination: true,
        dots: true,
        autoplay:false,
        autoplayTimeout: 4500,
        responsive: {
            0: {
                items: 1
            },
            576: {
                items: 1
            },
            992: {
                items: 1
            }
        }
    })
})