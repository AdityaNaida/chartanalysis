<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor fortified-testimonial-slider Widget.
 *
 * Elementor widget that uses the fortified-testimonial-slider control.
 *
 * @since 1.0.0
 */
class Elementor_Fortified_Testimonial_Slider_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve fortified-testimonial-slider widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'fortified-testimonial-slider';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve fortified-testimonial-slider widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Fortified Testimonial Slider', 'elementor-fortified-testimonial-slider-control' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve fortified-testimonial-slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-carousel-loop';
	}

	/**
	 * Register fortified-testimonial-slider widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'elementor-fortified-testimonial-slider-control' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'selected_style',
			[
				'label' => esc_html__( 'Select Style', 'elementor-fortified-testimonial-slider-control' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1', // Set the default style
				'options' => [
					'style1' => esc_html__( 'Style 1', 'elementor-fortified-testimonial-slider-control' ),
					'style2' => esc_html__( 'Style 2', 'elementor-fortified-testimonial-slider-control' ),
					'style3' => esc_html__( 'Style 3', 'elementor-fortified-testimonial-slider-control' ),
				],
			]
		);	
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'list_content', [
				'label' => __( 'Content', 'elementor-fortified-testimonial-slider-control' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'List Content' , 'elementor-fortified-testimonial-slider-control' ),
				'label_block' => true,
				'show_label' => false,
			]
		);
		$repeater->add_control(
			'list_image',
			[
				'label' => esc_html__( 'Image', 'elementor-fortified-testimonial-slider-control' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
				'default' => [
					'url' => PLUGIN_BASE_URI. 'assets/images/testimonial-default-img.png' ,
				],
			]
		);
		$repeater->add_control(
			'list_name', [
				'label' => __( 'Name', 'elementor-fortified-testimonial-slider-control' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Name' , 'elementor-fortified-testimonial-slider-control' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'list_designation', [
				'label' => __( 'Designation', 'elementor-fortified-testimonial-slider-control' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Designation' , 'elementor-fortified-testimonial-slider-control' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'list_image1',
			[
				'label' => esc_html__( 'Quote Image', 'elementor-fortified-testimonial-slider-control' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
				'default' => [
					'url' => PLUGIN_BASE_URI. 'assets/images/testimonial-default-img.png' ,
				],
			]
		);
		$this->add_control(
			'list',
			[
				'label' => __( 'Testimonial List', 'elementor-fortified-testimonial-slider-control' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_content' => __( 'Content', 'elementor-fortified-testimonial-slider-control' ),
						'list_image' => __( 'Image', 'elementor-fortified-testimonial-slider-control' ),
						'list_name' => __( 'Name', 'elementor-fortified-testimonial-slider-control' ),
						'list_designation' => __( 'Designation', 'elementor-fortified-testimonial-slider-control' ),
					],
					[
						'list_content' => __( 'Content', 'elementor-fortified-testimonial-slider-control' ),
						'list_image' => __( 'Image', 'elementor-fortified-testimonial-slider-control' ),
						'list_name' => __( 'Name', 'elementor-fortified-testimonial-slider-control' ),
						'list_designation' => __( 'Designation', 'elementor-fortified-testimonial-slider-control' ),
					],
				],
			]
		);
	}


	/**
	 * Render fortified-testimonial-slider widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$selected_style = $settings['selected_style'];
		if ($selected_style === 'style1') {
			?>
			<div class="testimonials-section position-relative">
				<div class="container">
					<div class="row" data-aos="fade-up">
						<div class="owl-carousel owl-theme">
							<?php
							if ($settings['list']) {
								foreach ($settings['list'] as $item) {
									?>
									<div class="item">
										<div class="testimonial-box float-left w-100">
											<ul class="list-unstyled">
												<li><i class="fa-solid fa-star"></i></li>
												<li><i class="fa-solid fa-star"></i></li>
												<li><i class="fa-solid fa-star"></i></li>
												<li><i class="fa-solid fa-star"></i></li>
												<li><i class="fa-solid fa-star"></i></li>
											</ul>
											<p class="review text-size-16">“<?php echo $item['list_content']; ?>”</p>
											<div class="info position-relative float-left w-100">
												<figure class="user-img mb-0">
													<?php echo wp_get_attachment_image($item['list_image']['id'], 'full'); ?>
												</figure>
												<div class="designation-outer">
													<h6 class="mb-0 member_name"><?php echo $item['list_name'] ?></h6>
													<p class="text-size-14 mb-0 member_designation"><?php echo $item['list_designation'] ?></p>
												</div>
												<figure class="quote-img position-absolute mb-0">
													<?php echo wp_get_attachment_image($item['list_image1']['id'], 'full'); ?>
												</figure>
											</div>
										</div>
									</div>
									<?php
								}
							}
							?>
						</div>
					</div>
				</div>
			</div>
			<?php
		} elseif ($selected_style === 'style2') {
			?>
			<div class="security_testimonial_section position-relative">
				<div class="testimonial_content">
					<div class="owl-carousel owl-theme">
						<?php
						if ($settings['list']) {
							foreach ($settings['list'] as $item) {
								?>
								<div class="item">
									<div class="testimonial-box float-left w-100">
										<p class="text-size-16">“<?php echo strip_tags($item['list_content']) ?>”</p>
										<div class="info position-relative float-left w-100">
											<ul class="list-unstyled">
												<li><i class="fa-solid fa-star"></i></li>
												<li><i class="fa-solid fa-star"></i></li>
												<li><i class="fa-solid fa-star"></i></li>
												<li><i class="fa-solid fa-star"></i></li>
												<li><i class="fa-solid fa-star"></i></li>
											</ul>
											<h6><?php echo $item['list_name'] ?></h6>
											<p class="text-size-14 mb-0"><?php echo $item['list_designation'] ?></p>
										</div>
									</div>
								</div>
								<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ($selected_style === 'style3') {
			?>
			<div class="secure_testimonial_section position-relative">
				<div class="owl-carousel owl-theme">
					<?php
					if ($settings['list']) {
						foreach ($settings['list'] as $item) {
							?>
							<div class="item">
								<div class="testimonial-box float-left w-100">
									<p class="text-size-16">“<?php echo strip_tags($item['list_content']) ?>”</p>
									<div class="info position-relative float-left w-100">
										<ul class="list-unstyled">
											<li><i class="fa-solid fa-star"></i></li>
											<li><i class="fa-solid fa-star"></i></li>
											<li><i class="fa-solid fa-star"></i></li>
											<li><i class="fa-solid fa-star"></i></li>
											<li><i class="fa-solid fa-star"></i></li>
										</ul>
										<h6><?php echo $item['list_name'] ?></h6>
										<p class="text-size-14 mb-0"><?php echo $item['list_designation'] ?></p>
									</div>
								</div>
							</div>
							<?php
						}
					}
					?>
				</div>
			</div>
			<?php
		}
	}
}