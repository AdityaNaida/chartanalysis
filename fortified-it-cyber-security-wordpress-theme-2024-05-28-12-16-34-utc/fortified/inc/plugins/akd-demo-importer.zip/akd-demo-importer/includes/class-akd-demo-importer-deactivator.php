<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://http://designingmedia.com/
 * @since      1.0.0
 *
 * @package    Akd_Demo_Importer
 * @subpackage Akd_Demo_Importer/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Akd_Demo_Importer
 * @subpackage Akd_Demo_Importer/includes
 * @author     Ammar Nasir <info@domain.com>
 */
class Akd_Demo_Importer_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
